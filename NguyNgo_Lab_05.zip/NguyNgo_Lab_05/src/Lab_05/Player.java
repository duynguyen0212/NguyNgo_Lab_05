/*
 *   Name: Ngoc Duy Nguyen
 *   Date: 2/16/2022
 *   Description: Player class for a sport team
 * */
package Lab_05;
public class Player {
    private String name;
    private int position;
    public String getName() {
        return name;
    }
    public int getPosition() {
        return position;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPosition(int position) {
        this.position = position;
    }
    public Player() {
        this.name = "Player A";
        this.position = 0;
    }
    public Player(String name, int position) {
        this.name = name;
        this.position = position;
    }
    public String toString() {
        return "Player's name: " + this.name + "/ Position: " + this.position;
    }
    /**
     * Check if player's name and position is the same or not
     */
    @Override
    public boolean equals(Object obj) {
        if (((Player) obj).getName() == this.name && (((Player) obj).getPosition()) == this.position) {
            return true;
        } else {
            return false;
        }
    }
}
